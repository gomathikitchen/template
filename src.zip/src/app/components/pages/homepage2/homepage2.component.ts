import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage2',
  templateUrl: './homepage2.component.html',
  styleUrls: ['./homepage2.component.css']
})
export class Homepage2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
