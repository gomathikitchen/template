import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-single-v1',
  templateUrl: './blog-single-v1.component.html',
  styleUrls: ['./blog-single-v1.component.css']
})
export class BlogSingleV1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
