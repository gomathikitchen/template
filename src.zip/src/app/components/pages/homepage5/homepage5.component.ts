import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage5',
  templateUrl: './homepage5.component.html',
  styleUrls: ['./homepage5.component.css']
})
export class Homepage5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
