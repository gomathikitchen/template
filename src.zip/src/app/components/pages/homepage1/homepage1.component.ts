import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage1',
  templateUrl: './homepage1.component.html',
  styleUrls: ['./homepage1.component.css']
})
export class Homepage1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
