import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-single-v3',
  templateUrl: './blog-single-v3.component.html',
  styleUrls: ['./blog-single-v3.component.css']
})
export class BlogSingleV3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
