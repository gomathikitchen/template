import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-single-v2',
  templateUrl: './blog-single-v2.component.html',
  styleUrls: ['./blog-single-v2.component.css']
})
export class BlogSingleV2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
