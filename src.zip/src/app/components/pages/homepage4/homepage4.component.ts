import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage4',
  templateUrl: './homepage4.component.html',
  styleUrls: ['./homepage4.component.css']
})
export class Homepage4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
