import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-archive',
  templateUrl: './recipe-archive.component.html',
  styleUrls: ['./recipe-archive.component.css']
})
export class RecipeArchiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
