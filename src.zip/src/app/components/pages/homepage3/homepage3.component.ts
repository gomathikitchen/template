import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage3',
  templateUrl: './homepage3.component.html',
  styleUrls: ['./homepage3.component.css']
})
export class Homepage3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
