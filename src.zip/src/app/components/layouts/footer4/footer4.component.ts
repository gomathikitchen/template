import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer4',
  templateUrl: './footer4.component.html',
  styleUrls: ['./footer4.component.css']
})
export class Footer4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
