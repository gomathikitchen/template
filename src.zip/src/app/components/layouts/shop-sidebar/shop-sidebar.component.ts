import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-sidebar',
  templateUrl: './shop-sidebar.component.html',
  styleUrls: ['./shop-sidebar.component.css']
})
export class ShopSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
