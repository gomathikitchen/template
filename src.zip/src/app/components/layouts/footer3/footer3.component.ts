import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer3',
  templateUrl: './footer3.component.html',
  styleUrls: ['./footer3.component.css']
})
export class Footer3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
