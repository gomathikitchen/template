import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-sidebar',
  templateUrl: './recipe-sidebar.component.html',
  styleUrls: ['./recipe-sidebar.component.css']
})
export class RecipeSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
