import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header4',
  templateUrl: './header4.component.html',
  styleUrls: ['./header4.component.css']
})
export class Header4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
